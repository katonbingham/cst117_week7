﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace W7ProgrammingExercise5
{
    public partial class Form1 : Form
    {
        int year;
        // int day;
        int result;

        public Form1()
        {
            InitializeComponent();
        }

        public int Result { get => result; set => result = value; }

        private void button1_Click(object sender, EventArgs e)
        {
            year = Convert.ToInt16(textBox1.Text);
            Random random = new Random(year);

            result = random.Next(1, 100);

            label6.Text = result.ToString();
            
            Form3 form3 = new Form3();
            form3.ShowDialog();
            form3.display(result.ToString());
            
        }
    }
}
