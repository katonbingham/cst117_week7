﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace W7ProgrammingExercise5
{
    public partial class Form3 : W7ProgrammingExercise5.Form1
    {
        public Form3()
        {
            InitializeComponent();
        }

        public void display(string s)
        {
            label6.Text = s;
        }
    }
}
